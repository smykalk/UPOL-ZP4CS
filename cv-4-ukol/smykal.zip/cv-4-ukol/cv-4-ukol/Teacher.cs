﻿
public class Rootobject {
	public Teacher[] Property1 { get; set; }
}

public class Teacher {
	public int ucitIdno { get; set; }
	public string jmeno { get; set; }
	public string prijmeni { get; set; }
	public string titulPred { get; set; }
	public string titulZa { get; set; }
	public string platnost { get; set; }
	public string zamestnanec { get; set; }
	public string katedra { get; set; }
	public string pracovisteDalsi { get; set; }
	public string email { get; set; }
	public string telefon { get; set; }
	public string telefon2 { get; set; }
	public string url { get; set; }
}
